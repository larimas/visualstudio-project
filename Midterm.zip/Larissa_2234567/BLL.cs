﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer
{
    internal class Employees
    {
        internal static int UpdateEmployees()
        {
            DataTable dt = Data.Employees.GetEmployees().GetChanges(DataRowState.Added | DataRowState.Modified);

            if ((dt != null) && (dt.Select("No employee can be less than 18 years old nor older than 120 years.").Length > 0))
            {
                Larissa_2234567.Form1.msgCommandYear();
                Data.Employees.GetEmployees().RejectChanges();
                return -1;
            }
            else
            {
                return Data.Employees.UpdateEmployees();
            }
        }
    }

    internal class Departments
    {
        internal static int UpdateDepartments()
        {
            return Data.Departments.UpdateDepartments();
        }
    }
}
