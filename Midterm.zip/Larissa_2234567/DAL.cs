﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data
{
    internal class Connect
    {
        private static String EmpDeptConnectionString = GetConnectString();
        internal static String ConnectionString { get => EmpDeptConnectionString; }
        private static String GetConnectString()
        {
            SqlConnectionStringBuilder cs = new SqlConnectionStringBuilder();
            cs.DataSource = "(local)";
            cs.InitialCatalog = "depEmployees";
            cs.UserID = "sa";
            cs.Password = "sysadm";
            return cs.ConnectionString;
        }
    }

    internal class DataTables
    {
        private static SqlDataAdapter adapterEmployees = InitAdapterEmployees();
        private static SqlDataAdapter adapterDepartments = InitAdapterDepartments();

        private static DataSet ds = InitDataSet();

        private static SqlDataAdapter InitAdapterEmployees()
        {
            SqlDataAdapter r = new SqlDataAdapter("SELECT * FROM Employees ORDER BY EmpId", Connect.ConnectionString);
            SqlCommandBuilder builder = new SqlCommandBuilder(r);
            r.UpdateCommand = builder.GetUpdateCommand();

            return r;
        }

        private static SqlDataAdapter InitAdapterDepartments()
        {
            SqlDataAdapter r = new SqlDataAdapter("SELECT * FROM Departments ORDER BY DeptId", Connect.ConnectionString);
            SqlCommandBuilder builder = new SqlCommandBuilder(r);
            // For the ON UPDATE CASCADE
            builder.ConflictOption = ConflictOption.OverwriteChanges;
            //
            r.UpdateCommand = builder.GetUpdateCommand();

            return r;
        }

        private static DataSet InitDataSet()
        {
            DataSet ds = new DataSet();
            loadDepartments(ds);
            loadEmployees(ds);

            return ds;
        }

        private static void loadEmployees(DataSet ds)
        {
            adapterEmployees.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            adapterEmployees.Fill(ds, "Employees"); // This is the database in the memory

            /* Foreign key between DataTables */

            ForeignKeyConstraint myFK = new ForeignKeyConstraint("MyFK",
                new DataColumn[]{
                ds.Tables["Departments"].Columns["DeptId"]
            },
            new DataColumn[]
            {
                ds.Tables["Employees"].Columns["DeptId"]
            }
            );
            myFK.DeleteRule = Rule.None;
            myFK.UpdateRule = Rule.Cascade;
            ds.Tables["Employees"].Constraints.Add(myFK);
        }

        private static void loadDepartments(DataSet ds)
        {
            adapterDepartments.MissingSchemaAction = MissingSchemaAction.AddWithKey;
            adapterDepartments.Fill(ds, "Departments"); // This is the database in the memory
        }

        internal static SqlDataAdapter getAdapterEmployees()
        {
            return adapterEmployees;
        }
        internal static SqlDataAdapter getAdapterDepartments()
        {
            return adapterDepartments;
        }
        internal static DataSet getDataSet()
        {
            return ds;
        }
    }
    internal class Employees
    {
        private static SqlDataAdapter adapter = DataTables.getAdapterEmployees();
        private static DataSet ds = DataTables.getDataSet();

        internal static DataTable GetEmployees()
        {
            return ds.Tables["Employees"];
        }

        internal static int UpdateEmployees()
        {
            if (!ds.Tables["Employees"].HasErrors)
            {
                return adapter.Update(ds.Tables["Employees"]);
            }
            else
            {
                return -1;
            }
        }
    }

    internal class Departments
    {
        private static SqlDataAdapter adapter = DataTables.getAdapterDepartments();
        private static DataSet ds = DataTables.getDataSet();

        internal static DataTable GetDepartments()
        {
            return ds.Tables["Departments"];
        }

        internal static int UpdateDepartments()
        {
            if (!ds.Tables["Departments"].HasErrors)
            {
                return adapter.Update(ds.Tables["Departments"]);
            }
            else
            {
                return -1;
            }
        }
    }






}
